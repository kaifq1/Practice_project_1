```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
dataframe = pd.read_csv("Zomato data .csv")
print(dataframe.head())
```

                        name online_order book_table   rate  votes  \
    0                  Jalsa          Yes        Yes  4.1/5    775   
    1         Spice Elephant          Yes         No  4.1/5    787   
    2        San Churro Cafe          Yes         No  3.8/5    918   
    3  Addhuri Udupi Bhojana           No         No  3.7/5     88   
    4          Grand Village           No         No  3.8/5    166   
    
       approx_cost(for two people) listed_in(type)  
    0                          800          Buffet  
    1                          800          Buffet  
    2                          800          Buffet  
    3                          300          Buffet  
    4                          600          Buffet  
    


```python
def handleRate(value):
	value=str(value).split('/')
	value=value[0];
	return float(value)

dataframe['rate']=dataframe['rate'].apply(handleRate)
print(dataframe.head())

```

                        name online_order book_table  rate  votes  \
    0                  Jalsa          Yes        Yes   4.1    775   
    1         Spice Elephant          Yes         No   4.1    787   
    2        San Churro Cafe          Yes         No   3.8    918   
    3  Addhuri Udupi Bhojana           No         No   3.7     88   
    4          Grand Village           No         No   3.8    166   
    
       approx_cost(for two people) listed_in(type)  
    0                          800          Buffet  
    1                          800          Buffet  
    2                          800          Buffet  
    3                          300          Buffet  
    4                          600          Buffet  
    


```python
dataframe.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 148 entries, 0 to 147
    Data columns (total 7 columns):
     #   Column                       Non-Null Count  Dtype  
    ---  ------                       --------------  -----  
     0   name                         148 non-null    object 
     1   online_order                 148 non-null    object 
     2   book_table                   148 non-null    object 
     3   rate                         148 non-null    float64
     4   votes                        148 non-null    int64  
     5   approx_cost(for two people)  148 non-null    int64  
     6   listed_in(type)              148 non-null    object 
    dtypes: float64(1), int64(2), object(4)
    memory usage: 8.2+ KB
    


```python
N = 10
top_n_restaurants = dataframe.nlargest(N, 'votes')
plt.figure(figsize=(10, 6))
sns.barplot(x='votes', y='name', data=top_n_restaurants, palette='viridis')
plt.xlabel("Votes", c="blue", size=15)
plt.ylabel("Restaurant Name", c="blue", size=15)
plt.title(f"Top {N} Restaurants by Votes")
plt.show()

```


    
![png](output_4_0.png)
    



```python
sns.countplot(x=dataframe['listed_in(type)'])
plt.xlabel("Type of restaurant")

```




    Text(0.5, 0, 'Type of restaurant')




    
![png](output_5_1.png)
    



```python
sns.countplot(x=dataframe['listed_in(type)'])
plt.xlabel("Type of restaurant")

```




    Text(0.5, 0, 'Type of restaurant')




    
![png](output_6_1.png)
    



```python
grouped_data = dataframe.groupby('listed_in(type)')['votes'].sum()
result = pd.DataFrame({'votes': grouped_data})
plt.plot(result, c="green", marker="o")
plt.xlabel("Type of restaurant", c="red", size=20)
plt.ylabel("Votes", c="red", size=20)
```




    Text(0, 0.5, 'Votes')




    
![png](output_7_1.png)
    



```python
max_votes = dataframe['votes'].max()
restaurant_with_max_votes = dataframe.loc[dataframe['votes'] == max_votes, 'name']

print("Restaurant with the maximum votes:")
print(restaurant_with_max_votes)

```

    Restaurant with the maximum votes:
    38    Empire Restaurant
    Name: name, dtype: object
    


```python
sns.countplot(x=dataframe['online_order'])

```




    <Axes: xlabel='online_order', ylabel='count'>




    
![png](output_9_1.png)
    



```python
plt.figure(figsize=(10, 6))
sns.scatterplot(x='votes', y='rate', data=dataframe, hue='online_order', palette='deep')
plt.xlabel("Votes", c="blue", size=15)
plt.ylabel("Rate", c="blue", size=15)
plt.title("Votes vs. Ratings")
plt.show()
```


    
![png](output_10_0.png)
    



```python
plt.hist(dataframe['rate'],bins=7)
plt.title("Ratings Distribution")
plt.show()

```


    
![png](output_11_0.png)
    



```python
avg_rating_by_type = dataframe.groupby('listed_in(type)')['rate'].mean().sort_values()
plt.figure(figsize=(10, 6))
sns.barplot(x=avg_rating_by_type.values, y=avg_rating_by_type.index, palette='coolwarm')
plt.xlabel("Average Rating", c="blue", size=15)
plt.ylabel("Type of Restaurant", c="blue", size=15)
plt.title("Average Rating by Restaurant Type")
plt.show()
```


    
![png](output_12_0.png)
    



```python
couple_data=dataframe['approx_cost(for two people)']
sns.countplot(x=couple_data)

```




    <Axes: xlabel='approx_cost(for two people)', ylabel='count'>




    
![png](output_13_1.png)
    



```python
plt.figure(figsize = (10,10))
sns.boxplot(x = 'online_order', y = 'rate', data = dataframe)

```




    <Axes: xlabel='online_order', ylabel='rate'>




    
![png](output_14_1.png)
    



```python
pivot_table = dataframe.pivot_table(index='listed_in(type)', columns='online_order', aggfunc='size', fill_value=0)
sns.heatmap(pivot_table, annot=True, cmap="YlGnBu", fmt='d')
plt.title("Heatmap")
plt.xlabel("Online Order")
plt.ylabel("Listed In (Type)")
plt.show()

```


    
![png](output_15_0.png)
    



```python
plt.figure(figsize=(10, 8))
corr_matrix = dataframe.corr()
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', center=0)
plt.title("Correlation Matrix")
plt.show()
```

    C:\Users\Kaif\AppData\Local\Temp\ipykernel_38796\951999127.py:2: FutureWarning: The default value of numeric_only in DataFrame.corr is deprecated. In a future version, it will default to False. Select only valid columns or specify the value of numeric_only to silence this warning.
      corr_matrix = dataframe.corr()
    


    
![png](output_16_1.png)
    


Dining restaurants mainly accept orders in person, while cafes primarily handle orders online. This indicates that customers prefer to place orders face-to-face at restaurants, but opt for online ordering at cafes.

